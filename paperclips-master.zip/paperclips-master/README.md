# Universal Paperclips, a game by Frank Lantz and Bennett Foddy

- [Mirrored](./mirror.sh) from [original](http://www.decisionproblem.com/paperclips/)
- Changes from original
  - [X] [remove GA](https://github.com/jgmize/paperclips/commit/2d3b2a2aaab01e9ee9f75e4975f803664b991c81)
  - [X] [uncomment cheats](https://github.com/jgmize/paperclips/commit/c3d578606b749bbf08ae4902a2e34a70fe370071)
  - [X] [git mv src docs](https://github.com/jgmize/paperclips/commit/4cacf17a4269ad680fb1569cf8e3355650bfc738) and [enable github pages from that folder](https://help.github.com/articles/configuring-a-publishing-source-for-github-pages/#publishing-your-github-pages-site-from-a-docs-folder-on-your-master-branch): https://jgmize.github.io/paperclips/
